import boto3
import re
import os

s3_client = boto3.client('s3')

def is_valid_filename(filename):
    """Check if filename contains only letters (no numbers or special characters)"""
    return bool(re.match("^[a-zA-Z]+$", filename.split('.')[0]))

def lambda_handler(event, context):
    bucket_name = os.environ["BUCKET_NAME"]
    validated_folder = os.environ["VALIDATED_FOLDER"]
    
    # Get file details from the event
    for record in event['Records']:
        s3_object = record['s3']
        source_key = s3_object['object']['key']
        
        filename = os.path.basename(source_key)  # Extract filename from key
        
        if is_valid_filename(filename):
            destination_key = f"{validated_folder}/{filename}"  # Use environment variable
            try:
                # Copy the file to the validated folder
                s3_client.copy_object(
                    Bucket=bucket_name,
                    CopySource={'Bucket': bucket_name, 'Key': source_key},
                    Key=destination_key
                )
                # Delete the original file from the source folder
                s3_client.delete_object(Bucket=bucket_name, Key=source_key)
                print(f"✅ File '{filename}' moved to '{validated_folder}/'")
            except Exception as e:
                print(f"❌ Error moving file {filename}: {str(e)}")
        else:
            print(f"🚫 Invalid filename '{filename}' - stays in allfiles/")
